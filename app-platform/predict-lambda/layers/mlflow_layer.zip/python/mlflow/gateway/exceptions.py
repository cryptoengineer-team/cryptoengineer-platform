class AIGatewayConfigException(Exception):
    pass
