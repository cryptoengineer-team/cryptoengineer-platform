import mlflow.pyfunc.loaders.chat_model
import mlflow.pyfunc.loaders.code_model  # noqa: F401
