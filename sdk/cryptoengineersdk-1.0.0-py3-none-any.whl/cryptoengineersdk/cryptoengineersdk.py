import requests
from io import BytesIO
import pandas as pd
import json

# URL de API de accesos al dato
URL_API_DATA = "https://q4feu6uy9j.execute-api.us-east-1.amazonaws.com/pro"
# URL de API de tokens
URL_API_TOKEN = "https://q4feu6uy9j.execute-api.us-east-1.amazonaws.com/pro"
# URL de API de tabla información
URL_API_TABLE_INFO = "https://q4feu6uy9j.execute-api.us-east-1.amazonaws.com/pro"


def reader (user_token: dict, table_name: str, symbol:str ='ALL_SYMBOLS', from_year:int = 0, to_year:int = 9999):
    # Función para la lectura de datos, donde llega un usuario y su token, y se solicita la lectura de datos

    # Validamos que los datos facilitados sean correctos
    if from_year > to_year:
        return f"The years are incorrect. The 'from_year' {from_year} must be equal or less than 'to_year' {to_year}. Please check the years."

    # Validamos si el usuario-token son correctos
    if user_auth(user_token):
        # Si son correctos, mostramos que el usuario ha sido autenticado
        print(f"{user_token['user']} was authenticated")

        # Obtenemos los datos de la tabla solicitada via API
        response = requests.get(f"{URL_API_DATA}/reader/{table_name}/{symbol}/{from_year}/{to_year}")
        data_urls = json.loads(response.content.decode('utf-8'))
        # Leemos lo devuelto por el api, para recorrer objeto por objeto y leer los datos de la url prefirmada
        dataframes =[]
        for url_presigned in data_urls:
            # Obtenemos el objeto y la url prefirmada
            object_key = url_presigned[0]
            url = url_presigned[1]
            # Si hay url, leemos el parquet de la url y lo añadimos a la lista de dataframes
            if url:
                df = read_parquet_from_url(url, object_key)
                dataframes.append(df)
                
        if dataframes != []:
            # Devolvemos el dataframe solicitado, concantenando todos los dataframes leídos
            return pd.concat(dataframes, ignore_index=True)
        else:
            # Devolvemos un dataframe vacío
            print(f"No data found for your request")
            return pd.DataFrame()
        

    
    # Si la validación de usuario-token no son correctos
    else:
        raise ("You don`t have access to data lake or your credentials are incorrect")


def get_info(user_token: dict):
    # Función para la obtención de información de la tabla, donde llega un usuario y su token, y se solicita la información de la tabla

    # Validamos si el usuario-token son correctos
    if user_auth(user_token):
        # Si son correctos, mostramos que el usuario ha sido autenticado
        print(f"{user_token['user']} was authenticated")
    else:
            # Si la validación de usuario-token no son correctos, devolvemos un mensaje de error
            raise ("You don`t have access to data lake or your credentials are incorrect")

    # Obtenemos la información de la tabla solicitada via API
    response = requests.get(f"{URL_API_TABLE_INFO}/list_info")
    data_urls = json.loads(response.content.decode('utf-8'))

    # Leemos lo devuelto por el api, para recorrer objeto por objeto y leer los datos de la url prefirmada
    dataframes =[]
    for url_presigned in data_urls:
        # Obtenemos el objeto y la url prefirmada
        object_key = url_presigned[0]
        url = url_presigned[1]
        # Si hay url, leemos el parquet de la url y lo añadimos a la lista de dataframes
        if url:
            df = read_parquet_from_url(url, object_key)
            dataframes.append(df)

    if dataframes != []:
        # Devolvemos el dataframe solicitado, concantenando todos los dataframes leídos
        return pd.concat(dataframes, ignore_index=True)
    else:
        # Devolvemos un dataframe vacío
        print(f"No data found for your request")
        return pd.DataFrame()
    

def user_auth(user_token:dict):
    # Función para la validación del usuario, donde llega un usuario y su token, validando que sean correctos

    # Obtenemos el usuario facilitado
    user =user_token['user']
    # Obtenemos el token facilitado
    token = user_token['token']
    # Validamos si son correctos
    response = requests.get(f"{URL_API_TOKEN}/token/{user}/{token}")
    # Si el resultado es "Granted access" devolvemos True, si no, devolvemos False
    if response.content.decode('utf-8').strip("\"") == "Granted access":
        return True
    else:
        return False


def read_parquet_from_url(url, object_key):
    # Función para la lectura de un parquet desde una url, devolviendo un dataframe

    # Obtenemos la respuesta de la url
    response = requests.get(url)

    if response.status_code == 200:
        # Obtenemos el contenido de la respuesta y lo leemos con pandas
        response_data = BytesIO(response.content)
        df_url = pd.read_parquet(response_data)
        # Obtenemos las particiones de la tabla
        list_partitions = obtain_partitions_from_object_key(object_key)
        # Si hay particiones, las añadimos al dataframe
        if list_partitions != []:
            for partition in list_partitions:
                df_url[partition[0]] = partition[1]
        # Devolvemos el dataframe
        return df_url
    else:
        print(f"Failed to read {url}")
        return pd.DataFrame()


def obtain_partitions_from_object_key(object_key):
    # Función para la obtención de las particiones de una tabla a partir de un object_key
    list_part = [x.split("=") for x in object_key.split('/') if '=' in x and x != object_key.split('/')[-1]]

    return (list_part)

